#!/usr/bin/python

#
# Imports
#
import sys, os, shlex;
from time import localtime;

# Run Schedule Importer script to create schedule_today file
os.system('./HA_Schedule_Importer.py');

def App():
    #
    # Variables
    #
    Currenttime = localtime()[3];
    strCurrenttime = '';

    Sensortemp = 5;
    strSensortemp = '';

    Schedtemp = 0;
    strSchedtemp = '';

    Tempdiff = 0;
    strTempdiff = '';

    Temprate = 1;
    Temptimereq = 0;
    strTemptimereq = '';

    #
    # Processing
    #
    # Read todays schedule file
    schedfile = open('/home/pi/.homeautomation/Schedule/schedule_today', 'r');
    Schedule = schedfile.read();

    # Split 'Schedule' into comma separated list
    split = shlex.shlex(Schedule);
    split.whitespace += ',';
    split.whitespace_split = True;
    Schedule = list(split);

    # Set Schedtemp as this hours value in the list
    Schedtemp = Schedule[Currenttime + 1];

    # Calculate temperature difference
    Tempdiff = int(Schedtemp) - Sensortemp;

    # Calculate heating time req
    Temptimereq = Tempdiff / Temprate;

    #
    # Formatting
    #
    # Format time string
    strCurrenttime = str(Currenttime);
    strCurrenttime += ":00";

    # Format schedule temperature string
    strSchedtemp = str(Schedtemp);
    strSchedtemp += "*C";

    # Format sensor temperature string
    strSensortemp = str(Sensortemp);
    strSensortemp += "*C";

    # Format temperature difference string
    strTempdiff = str(Tempdiff);
    strTempdiff += "*C";

    # Format heating time string
    strTemptimereq = str(Temptimereq);
    strTemptimereq += " mins";

    #
    # Display
    #
    os.system('clear');
    print "System Monitor";
    print;
    print "##############";
    print "#  Overview  #";
    print "##############";
    print;
    print "No. of sensors reporting: ", "1 Virtual Sensor";
    print;
    print "###############";
    print "# Temperature #";
    print "###############";
    print;
    print "The temperature at", strCurrenttime, "should be", strSchedtemp;
    print "The temperature is currently:", strSensortemp;
    print "This is a difference of:", strTempdiff;
    if Tempdiff > 0:
        print "The heater will be activated for", strTemptimereq[1:];
    else:
        print "The fan will be activated for", strTemptimereq[1:]
    print;

def Menu():
    # Main menu
    # Clear screen
    os.system('clear');
    print "Home Automation System";
    print "Main Menu:";
    print;
    print "1) System Monitor";
    print "2) Exit";
    print;
    return input ("Option: ");

loop = 1
choice = 0
while loop == 1:
    choice = Menu();
    if choice == 1:
        App();
        x = raw_input("Press Enter to Return to Menu");
    elif choice == 2:
        os.system('clear');
        break;
