#!/usr/bin/python

# System imports
import sys, shlex;
from time import localtime;

# Importing Schedule
schedule = [line.strip() for line in open('/home/pi/.homeautomation/Schedule/schedule')];

# Formatting/reading schedule into array (CURRENTLY UNUSED)
#split = shlex.shlex(schedule[localtime()[6]]);
#split.whitespace += ',';
#split.whitespace_split = True;
#schedtoday = list(split);

# Write todays schedule to file schedule_today
schedfile = open('/home/pi/.homeautomation/Schedule/schedule_today', 'w');
schedtoday = str(schedule[localtime()[6]]);
schedfile.write(schedtoday);