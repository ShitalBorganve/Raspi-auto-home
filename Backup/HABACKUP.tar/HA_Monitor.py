#!/usr/bin/python

#
# Imports
#
import sys, os, shlex;
from time import localtime;

# Run Schedule Importer script to create schedule_today file
os.system('./HA_Schedule_Importer.py');

#
# Variables
#
Currenttime = localtime()[3];
strCurrenttime = '';

Sensortemp = 5;
strSensortemp = '';

strSchedtemp = '';

Tempdiff = 0;
strTempdiff = '';

Temprate = 1;
Temptimereq = 0;
strTemptimereq = '';

#
# Processing
#
# Read todays schedule file
schedfile = open('/home/pi/.homeautomation/Schedule/schedule_today', 'r');
Schedule = schedfile.read();

# Split 'Schedule' into comma separated list
split = shlex.shlex(Schedule);
split.whitespace += ',';
split.whitespace_split = True;
Schedule = list(split);

# Set Schedtemp as this hours value in the list
Schedtemp = Schedule[Currenttime + 1];

# Calculate temperature difference
Tempdiff = int(Schedtemp) - Sensortemp;

# Calculate heating time req
Temptimereq = Tempdiff / Temprate;

# Format time string
strCurrenttime = str(Currenttime);
strCurrenttime += ":00";

# Format schedule temperature string
strSchedtemp = str(Schedtemp);
strSchedtemp += "*C";

# Format sensor temperature string
strSensortemp = str(Sensortemp);
strSensortemp += "*C";

# Format temperature difference string
strTempdiff = str(Tempdiff);
strTempdiff += "*C";

# Format heating time string
strTemptimereq = str(Temptimereq);
strTemptimereq += " mins";

#
# Display
#
print "The temperature at", strCurrenttime, "should be", strSchedtemp;
print "The temperature is currently:", strSensortemp;
print "This is a difference of:", strTempdiff;
print "The heater will be activated for", strTemptimereq;